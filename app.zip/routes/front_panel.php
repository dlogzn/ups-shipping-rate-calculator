<?php
use Illuminate\Support\Facades\Route;

Route::group(['prefix' => ''], function () {

});

