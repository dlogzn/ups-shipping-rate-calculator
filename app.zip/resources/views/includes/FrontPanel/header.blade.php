<div class="container-fluid background_color_default">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 mx-auto">



        </div>
    </div>
</div>


<script type="text/javascript">



    $(document).ready(function () {


    });




</script>
