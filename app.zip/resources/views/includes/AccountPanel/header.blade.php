<div class="container-fluid">
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 mx-auto">
            <nav class="navbar bg-body-tertiary">
                <a class="navbar-brand" href="#">
                    <img src="https://wwwapps.ups.com/assets/resources/images/UPS_logo.svg" alt="Logo" width="30" height="24" style="margin-left: -5px;" class="d-inline-block align-text-top">
                    UPS Shipping Rate Calculator
                </a>
            </nav>


        </div>
    </div>
</div>


<script type="text/javascript">



    $(document).ready(function () {


    });




</script>
