
<div class="container-fluid" style="background-color: #f8f8f8;">
    <div class="row py-5">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 mx-auto">



            <div class="row mt-3">
                <div class="col text-center ">
                    <span class=" text-muted">&copy; {{ date('Y') }} UPS Shipping Rate Calculator</span>
                </div>
            </div>



        </div>
    </div>
</div>
