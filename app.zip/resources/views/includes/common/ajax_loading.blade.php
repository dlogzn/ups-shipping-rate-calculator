<div id="ajax_loading">
    <div class="ajax_loading_spinner">
        <span class="loading_spinner"></span>
    </div>
</div>
